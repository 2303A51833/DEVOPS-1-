export const studentsData = [
  {
    id: "STU-101",
    name: "Aarav Sharma",
    rollNumber: "CS2023048",
    branch: "Computer Science & Engineering",
    year: "3rd Year",
    semester: "Semester VI",
    email: "aarav.sharma@apex.edu",
    phone: "+91 98765 43210",
    avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=250&q=80",
    cgpa: "9.12",
    advisor: "Dr. K. S. Ramanujan",
    attendance: {
      percentage: 88.5,
      totalClasses: 240,
      attendedClasses: 212,
      minRequired: 75.0,
      lastUpdated: "Today, 09:30 AM"
    },
    subjects: [
      {
        code: "CS601",
        name: "Design & Analysis of Algorithms",
        credits: 4,
        faculty: "Prof. Arvind Mehra",
        type: "Theory + Lab",
        attendance: 92,
        grade: "A+"
      },
      {
        code: "CS602",
        name: "Operating Systems",
        credits: 4,
        faculty: "Dr. Sangeeta Rao",
        type: "Theory",
        attendance: 87,
        grade: "A"
      },
      {
        code: "CS603",
        name: "Database Management Systems",
        credits: 3,
        faculty: "Prof. Vikram Sen",
        type: "Theory + Lab",
        attendance: 90,
        grade: "A+"
      },
      {
        code: "CS604",
        name: "Machine Learning Fundamentals",
        credits: 4,
        faculty: "Dr. Neha Mukherjee",
        type: "Theory",
        attendance: 85,
        grade: "A"
      },
      {
        code: "CS605",
        name: "Computer Networks",
        credits: 3,
        faculty: "Prof. Rajesh Pillai",
        type: "Theory",
        attendance: 86,
        grade: "B+"
      },
      {
        code: "CS606L",
        name: "Software Engineering & Cloud Lab",
        credits: 2,
        faculty: "Prof. Arvind Mehra",
        type: "Practical",
        attendance: 94,
        grade: "O"
      }
    ],
    exams: [
      {
        code: "CS601",
        subject: "Design & Analysis of Algorithms",
        date: "May 12, 2026",
        time: "10:00 AM - 01:00 PM",
        room: "Hall A-204",
        seatNumber: "A-42",
        status: "Confirmed"
      },
      {
        code: "CS602",
        subject: "Operating Systems",
        date: "May 15, 2026",
        time: "10:00 AM - 01:00 PM",
        room: "Hall A-204",
        seatNumber: "A-42",
        status: "Confirmed"
      },
      {
        code: "CS603",
        subject: "Database Management Systems",
        date: "May 18, 2026",
        time: "02:00 PM - 05:00 PM",
        room: "Hall B-101",
        seatNumber: "B-18",
        status: "Confirmed"
      },
      {
        code: "CS604",
        subject: "Machine Learning Fundamentals",
        date: "May 21, 2026",
        time: "10:00 AM - 01:00 PM",
        room: "Hall A-204",
        seatNumber: "A-42",
        status: "Confirmed"
      },
      {
        code: "CS605",
        subject: "Computer Networks",
        date: "May 25, 2026",
        time: "02:00 PM - 05:00 PM",
        room: "Hall C-305",
        seatNumber: "C-09",
        status: "Confirmed"
      }
    ]
  },
  {
    id: "STU-102",
    name: "Priya Patel",
    rollNumber: "AI2023019",
    branch: "Artificial Intelligence & Data Science",
    year: "3rd Year",
    semester: "Semester VI",
    email: "priya.patel@apex.edu",
    phone: "+91 91234 56789",
    avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=250&q=80",
    cgpa: "7.85",
    advisor: "Dr. Shalini Gupta",
    attendance: {
      percentage: 68.0,
      totalClasses: 240,
      attendedClasses: 163,
      minRequired: 75.0,
      lastUpdated: "Yesterday, 04:15 PM"
    },
    subjects: [
      {
        code: "AI601",
        name: "Deep Learning Architectures",
        credits: 4,
        faculty: "Dr. Shalini Gupta",
        type: "Theory + Lab",
        attendance: 65,
        grade: "B"
      },
      {
        code: "AI602",
        name: "Natural Language Processing",
        credits: 4,
        faculty: "Prof. Hemant Joshi",
        type: "Theory",
        attendance: 70,
        grade: "B+"
      },
      {
        code: "AI603",
        name: "Big Data Analytics & Spark",
        credits: 3,
        faculty: "Dr. Anirudh Roy",
        type: "Theory + Lab",
        attendance: 64,
        grade: "B"
      },
      {
        code: "AI604",
        name: "Cloud Computing & MLOps",
        credits: 3,
        faculty: "Prof. Divya Nair",
        type: "Theory",
        attendance: 72,
        grade: "B+"
      },
      {
        code: "AI605L",
        name: "Neural Networks Simulation Lab",
        credits: 2,
        faculty: "Dr. Shalini Gupta",
        type: "Practical",
        attendance: 69,
        grade: "A"
      }
    ],
    exams: [
      {
        code: "AI601",
        subject: "Deep Learning Architectures",
        date: "May 13, 2026",
        time: "10:00 AM - 01:00 PM",
        room: "Hall C-102",
        seatNumber: "Pending Verification",
        status: "Admit Card On Hold"
      },
      {
        code: "AI602",
        subject: "Natural Language Processing",
        date: "May 16, 2026",
        time: "10:00 AM - 01:00 PM",
        room: "Hall C-102",
        seatNumber: "Pending Verification",
        status: "Admit Card On Hold"
      },
      {
        code: "AI603",
        subject: "Big Data Analytics & Spark",
        date: "May 19, 2026",
        time: "02:00 PM - 05:00 PM",
        room: "Hall C-102",
        seatNumber: "Pending Verification",
        status: "Admit Card On Hold"
      },
      {
        code: "AI604",
        subject: "Cloud Computing & MLOps",
        date: "May 22, 2026",
        time: "10:00 AM - 01:00 PM",
        room: "Hall C-102",
        seatNumber: "Pending Verification",
        status: "Admit Card On Hold"
      }
    ]
  },
  {
    id: "STU-103",
    name: "Rohan Verma",
    rollNumber: "EC2022084",
    branch: "Electronics & Communication Engineering",
    year: "4th Year",
    semester: "Semester VIII",
    email: "rohan.verma@apex.edu",
    phone: "+91 97890 12345",
    avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=250&q=80",
    cgpa: "8.94",
    advisor: "Prof. M. K. Swamy",
    attendance: {
      percentage: 94.2,
      totalClasses: 220,
      attendedClasses: 207,
      minRequired: 75.0,
      lastUpdated: "Today, 11:00 AM"
    },
    subjects: [
      {
        code: "EC801",
        name: "VLSI System Design",
        credits: 4,
        faculty: "Dr. K. V. Sridhar",
        type: "Theory + Lab",
        attendance: 96,
        grade: "O"
      },
      {
        code: "EC802",
        name: "Wireless & 5G Communications",
        credits: 4,
        faculty: "Prof. M. K. Swamy",
        type: "Theory",
        attendance: 93,
        grade: "A+"
      },
      {
        code: "EC803",
        name: "Embedded IoT Architecture",
        credits: 3,
        faculty: "Dr. Pratibha Rao",
        type: "Theory + Lab",
        attendance: 95,
        grade: "O"
      },
      {
        code: "EC804P",
        name: "Major Capstone Project",
        credits: 6,
        faculty: "Dept. Evaluation Committee",
        type: "Project",
        attendance: 98,
        grade: "O"
      }
    ],
    exams: [
      {
        code: "EC801",
        subject: "VLSI System Design",
        date: "May 11, 2026",
        time: "10:00 AM - 01:00 PM",
        room: "Hall D-401",
        seatNumber: "D-14",
        status: "Confirmed"
      },
      {
        code: "EC802",
        subject: "Wireless & 5G Communications",
        date: "May 14, 2026",
        time: "10:00 AM - 01:00 PM",
        room: "Hall D-401",
        seatNumber: "D-14",
        status: "Confirmed"
      },
      {
        code: "EC803",
        subject: "Embedded IoT Architecture",
        date: "May 17, 2026",
        time: "02:00 PM - 05:00 PM",
        room: "Hall D-401",
        seatNumber: "D-14",
        status: "Confirmed"
      }
    ]
  },
  {
    id: "STU-104",
    name: "Ananya Iyer",
    rollNumber: "IT2024032",
    branch: "Information Technology",
    year: "2nd Year",
    semester: "Semester IV",
    email: "ananya.iyer@apex.edu",
    phone: "+91 94567 89012",
    avatar: "https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=250&q=80",
    cgpa: "8.40",
    advisor: "Prof. Geeta Sundaram",
    attendance: {
      percentage: 73.5,
      totalClasses: 260,
      attendedClasses: 191,
      minRequired: 75.0,
      lastUpdated: "Today, 08:45 AM"
    },
    subjects: [
      {
        code: "IT401",
        name: "Web Development Frameworks",
        credits: 4,
        faculty: "Prof. Geeta Sundaram",
        type: "Theory + Lab",
        attendance: 78,
        grade: "A"
      },
      {
        code: "IT402",
        name: "Discrete Mathematics & Graph Theory",
        credits: 4,
        faculty: "Dr. P. N. Murthy",
        type: "Theory",
        attendance: 71,
        grade: "B+"
      },
      {
        code: "IT403",
        name: "Computer Organization & Architecture",
        credits: 3,
        faculty: "Prof. Tarun Sen",
        type: "Theory",
        attendance: 72,
        grade: "B+"
      },
      {
        code: "IT404",
        name: "Object-Oriented Programming with Java",
        credits: 4,
        faculty: "Dr. Leena Thomas",
        type: "Theory + Lab",
        attendance: 74,
        grade: "A"
      },
      {
        code: "IT405L",
        name: "Database Systems Practicum",
        credits: 2,
        faculty: "Prof. Geeta Sundaram",
        type: "Practical",
        attendance: 75,
        grade: "A"
      }
    ],
    exams: [
      {
        code: "IT401",
        subject: "Web Development Frameworks",
        date: "May 13, 2026",
        time: "02:00 PM - 05:00 PM",
        room: "Auditorium Annex",
        seatNumber: "Pending Condonation",
        status: "Attendance Shortfall Alert"
      },
      {
        code: "IT402",
        subject: "Discrete Mathematics & Graph Theory",
        date: "May 16, 2026",
        time: "02:00 PM - 05:00 PM",
        room: "Auditorium Annex",
        seatNumber: "Pending Condonation",
        status: "Attendance Shortfall Alert"
      },
      {
        code: "IT403",
        subject: "Computer Organization & Architecture",
        date: "May 20, 2026",
        time: "10:00 AM - 01:00 PM",
        room: "Auditorium Annex",
        seatNumber: "Pending Condonation",
        status: "Attendance Shortfall Alert"
      }
    ]
  }
];
