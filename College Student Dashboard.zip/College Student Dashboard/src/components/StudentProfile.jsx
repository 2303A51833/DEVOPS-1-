import React from 'react';

/**
 * StudentProfile Component
 * Displays comprehensive student profile details received via props:
 * name, roll number, branch, and year (along with contact and academic details).
 *
 * @param {Object} props
 * @param {Object} props.student - Student object containing details
 */
export default function StudentProfile({ student }) {
  if (!student) {
    return (
      <div className="card profile-card empty-state">
        <p>No student profile data available.</p>
      </div>
    );
  }

  const {
    name,
    rollNumber,
    branch,
    year,
    semester,
    email,
    phone,
    avatar,
    cgpa,
    advisor
  } = student;

  return (
    <section className="card profile-card" aria-label="Student Profile">
      <div className="profile-banner-bg"></div>

      <div className="profile-content">
        <div className="profile-header-group">
          <div className="avatar-wrapper">
            <img 
              src={avatar} 
              alt={`${name}'s photo`} 
              className="student-avatar-lg" 
            />
            <span className="online-indicator" title="Enrolled & Active"></span>
          </div>

          <div className="profile-identity">
            <div className="name-and-status">
              <h2 className="student-name" id="student-name-display">{name}</h2>
              <span className="status-chip active-chip">Enrolled</span>
            </div>
            <p className="student-roll">
              <span className="label-dim">Roll No:</span> <strong>{rollNumber}</strong>
            </p>
            <p className="student-branch">
              <span className="branch-tag">{branch}</span>
            </p>
          </div>
        </div>

        <div className="profile-details-grid">
          <div className="profile-field-box">
            <span className="field-label">Current Academic Year</span>
            <span className="field-value" id="student-year-display">{year}</span>
            <span className="field-sub">{semester}</span>
          </div>

          <div className="profile-field-box">
            <span className="field-label">Cumulative GPA (CGPA)</span>
            <span className="field-value highlight-cgpa">{cgpa} <span className="max-grade">/ 10</span></span>
            <span className="field-sub">First Class with Distinction</span>
          </div>

          <div className="profile-field-box">
            <span className="field-label">Official Student Email</span>
            <span className="field-value text-break">
              <a href={`mailto:${email}`} className="profile-link">{email}</a>
            </span>
            <span className="field-sub">Apex Institute Institutional ID</span>
          </div>

          <div className="profile-field-box">
            <span className="field-label">Faculty Advisor</span>
            <span className="field-value">{advisor || "Assigned Department Mentor"}</span>
            <span className="field-sub">Contact: {phone}</span>
          </div>
        </div>
      </div>
    </section>
  );
}
