import React from 'react';

/**
 * Header Component
 * Displays the College Name, Application Title, and system status indicators.
 * @param {Object} props
 * @param {string} props.collegeName - Name of the college/university
 * @param {string} props.dashboardTitle - Title of the dashboard application
 * @param {string} props.academicYear - Current academic year or term
 * @param {Object} props.activeStudent - Active student details
 */
export default function Header({ 
  collegeName = "Apex Institute of Technology & Sciences", 
  dashboardTitle = "Student Management Dashboard",
  academicYear = "Academic Year 2025–2026",
  activeStudent
}) {
  return (
    <header className="dashboard-header">
      <div className="header-brand-container">
        <div className="college-emblem">
          <svg width="34" height="34" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M22 10v6M2 10l10-5 10 5-10 5z"/>
            <path d="M6 12v5c3 3 9 3 12 0v-5"/>
          </svg>
        </div>
        <div className="header-titles">
          <span className="college-name-badge">{collegeName}</span>
          <h1 className="application-title" id="dashboard-heading">{dashboardTitle}</h1>
        </div>
      </div>

      <div className="header-actions">
        <div className="term-badge">
          <span className="live-dot"></span>
          <span>{academicYear}</span>
        </div>

        {activeStudent && (
          <div className="active-student-pill">
            <img 
              src={activeStudent.avatar} 
              alt={activeStudent.name} 
              className="active-avatar"
            />
            <div className="active-meta">
              <span className="active-name">{activeStudent.name}</span>
              <span className="active-roll">{activeStudent.rollNumber}</span>
            </div>
          </div>
        )}
      </div>
    </header>
  );
}
