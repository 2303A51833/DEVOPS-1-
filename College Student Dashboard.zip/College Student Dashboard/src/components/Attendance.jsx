import React, { useState } from 'react';

/**
 * Attendance Component
 * Displays student attendance dynamically.
 * Features conditional rendering for "Eligible" or "Not Eligible" based on 75% threshold.
 * Includes interactive test slider to simulate varying attendance percentages dynamically!
 *
 * @param {Object} props
 * @param {Object} props.attendance - Attendance object containing percentage, totalClasses, attendedClasses
 */
export default function Attendance({ attendance }) {
  if (!attendance) {
    return (
      <div className="card attendance-card empty-state">
        <p>Attendance record not available.</p>
      </div>
    );
  }

  // Interactive adjustment slider (initialized to the student's actual attendance)
  const [simulatedPct, setSimulatedPct] = useState(attendance.percentage);

  // Sync with prop change if different student is selected
  React.useEffect(() => {
    setSimulatedPct(attendance.percentage);
  }, [attendance.percentage]);

  const minRequired = attendance.minRequired || 75.0;
  const currentPercentage = simulatedPct;
  const isEligible = currentPercentage >= minRequired;
  
  // Calculate shortage or surplus classes (based on 240 default classes)
  const totalClasses = attendance.totalClasses || 240;
  const attendedCount = Math.round((currentPercentage / 100) * totalClasses);
  const requiredCount = Math.ceil((minRequired / 100) * totalClasses);
  const diffClasses = attendedCount - requiredCount;

  return (
    <section className="card attendance-card" aria-label="Attendance Status">
      <div className="card-header-bar">
        <div>
          <h2 className="card-title">Attendance Tracking & Eligibility</h2>
          <p className="card-subtitle">Mandatory Institutional Minimum: <strong>{minRequired}%</strong></p>
        </div>

        {/* CONDITIONAL RENDERING BONUS CHALLENGE */}
        <div className="eligibility-badge-wrapper">
          {isEligible ? (
            <div className="eligibility-status-badge eligible" id="eligibility-status">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/>
                <polyline points="22 4 12 14.01 9 11.01"/>
              </svg>
              <span>Eligible for Exams</span>
            </div>
          ) : (
            <div className="eligibility-status-badge not-eligible" id="eligibility-status">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                <circle cx="12" cy="12" r="10"/>
                <line x1="15" y1="9" x2="9" y2="15"/>
                <line x1="9" y1="9" x2="15" y2="15"/>
              </svg>
              <span>Not Eligible (Shortfall)</span>
            </div>
          )}
        </div>
      </div>

      <div className="attendance-body-grid">
        {/* Visual Percentage Display */}
        <div className="attendance-metric-display">
          <div className="percentage-circle-container">
            <svg viewBox="0 0 36 36" className="circular-chart">
              <path
                className="circle-bg"
                d="M18 2.0845
                  a 15.9155 15.9155 0 0 1 0 31.831
                  a 15.9155 15.9155 0 0 1 0 -31.831"
              />
              <path
                className={`circle-progress ${isEligible ? 'stroke-good' : 'stroke-warn'}`}
                strokeDasharray={`${currentPercentage}, 100`}
                d="M18 2.0845
                  a 15.9155 15.9155 0 0 1 0 31.831
                  a 15.9155 15.9155 0 0 1 0 -31.831"
              />
            </svg>
            <div className="percentage-text-inner">
              <span className="big-pct-value" id="attendance-pct-display">{currentPercentage}%</span>
              <span className="pct-caption">Total Ratio</span>
            </div>
          </div>

          <div className="stat-pills-column">
            <div className="stat-pill-item">
              <span className="pill-lbl">Attended Sessions</span>
              <strong className="pill-val">{attendedCount} / {totalClasses}</strong>
            </div>
            <div className="stat-pill-item">
              <span className="pill-lbl">Required for Eligibility</span>
              <strong className="pill-val">{requiredCount} Classes ({minRequired}%)</strong>
            </div>
            <div className="stat-pill-item">
              <span className="pill-lbl">Margin / Status</span>
              <strong className={`pill-val ${diffClasses >= 0 ? 'text-good' : 'text-warn'}`}>
                {diffClasses >= 0 ? `+${diffClasses} classes buffer` : `${diffClasses} classes shortage`}
              </strong>
            </div>
          </div>
        </div>

        {/* Conditional Alert Notice & Simulation Controls */}
        <div className="attendance-status-notice-col">
          {/* Conditional Rendering Notice Card */}
          {isEligible ? (
            <div className="notice-box notice-eligible">
              <div className="notice-icon">✓</div>
              <div className="notice-text">
                <h4>Examination Hall Clearance Granted</h4>
                <p>
                  You have successfully satisfied the institutional attendance criterion of <strong>{minRequired}%</strong>.
                  Your examination hall ticket is authorized and available for printing.
                </p>
              </div>
            </div>
          ) : (
            <div className="notice-box notice-not-eligible">
              <div className="notice-icon">⚠</div>
              <div className="notice-text">
                <h4>Warning: Shortage of Attendance</h4>
                <p>
                  Your attendance is currently <strong>{currentPercentage}%</strong>, which is below the mandatory 
                  <strong> {minRequired}%</strong> requirement. You are currently <strong>Not Eligible</strong> to write
                  the end-semester examinations. Please consult your Academic Advisor immediately for condonation procedures.
                </p>
              </div>
            </div>
          )}

          {/* Interactive Attendance Simulation */}
          <div className="attendance-simulator-box">
            <div className="simulator-header">
              <label htmlFor="attendance-slider" className="simulator-label">
                Interactive Attendance Simulator:
              </label>
              <button 
                type="button" 
                className="reset-slider-btn"
                onClick={() => setSimulatedPct(attendance.percentage)}
                title="Reset to official record"
              >
                Reset ({attendance.percentage}%)
              </button>
            </div>
            <input 
              id="attendance-slider"
              type="range" 
              min="40" 
              max="100" 
              step="0.5"
              value={simulatedPct} 
              onChange={(e) => setSimulatedPct(parseFloat(e.target.value))}
              className="attendance-slider"
            />
            <div className="slider-ticks">
              <span>40%</span>
              <span className="threshold-mark">Threshold: 75%</span>
              <span>100%</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
