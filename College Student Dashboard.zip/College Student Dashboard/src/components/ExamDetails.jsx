import React, { useState } from 'react';

/**
 * ExamDetails Component
 * Displays the examination timetable, room allotment, seating, and admit card status.
 *
 * @param {Object} props
 * @param {Array} props.exams - Array of exam schedules
 * @param {boolean} props.isEligible - Whether the student is eligible based on attendance
 * @param {string} props.studentName - Name of the student
 * @param {string} props.rollNumber - Roll number of the student
 */
export default function ExamDetails({ 
  exams = [], 
  isEligible = true,
  studentName = "",
  rollNumber = "" 
}) {
  const [showAdmitCardModal, setShowAdmitCardModal] = useState(false);

  return (
    <section className="card exam-card" aria-label="Examination Schedule">
      <div className="card-header-bar">
        <div>
          <h2 className="card-title">End-Semester Examination Schedule</h2>
          <p className="card-subtitle">
            Upcoming Assessments • Controller of Examinations (CoE) Portal
          </p>
        </div>

        <div className="exam-action-buttons">
          <button
            type="button"
            className={`btn-admit-card ${isEligible ? 'btn-enabled' : 'btn-disabled'}`}
            disabled={!isEligible}
            onClick={() => isEligible && setShowAdmitCardModal(true)}
            title={isEligible ? "View and download official Hall Ticket" : "Admit Card withheld due to attendance shortage"}
          >
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
              <polyline points="7 10 12 15 17 10"/>
              <line x1="12" y1="15" x2="12" y2="3"/>
            </svg>
            <span>{isEligible ? "Download Hall Ticket / Admit Card" : "Hall Ticket On Hold"}</span>
          </button>
        </div>
      </div>

      <div className="exam-table-responsive">
        <table className="exam-table">
          <thead>
            <tr>
              <th>Course Code</th>
              <th>Subject</th>
              <th>Exam Date</th>
              <th>Session / Timing</th>
              <th>Assigned Hall</th>
              <th>Desk / Seat</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {exams.length === 0 ? (
              <tr>
                <td colSpan="7" className="text-center py-4">No examination schedule currently posted.</td>
              </tr>
            ) : (
              exams.map((item, idx) => (
                <tr key={item.code || idx} className="exam-table-row">
                  <td>
                    <span className="code-badge-subtle">{item.code}</span>
                  </td>
                  <td>
                    <strong>{item.subject}</strong>
                  </td>
                  <td>
                    <div className="date-block">
                      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="mr-1">
                        <rect x="3" y="4" width="18" height="18" rx="2" ry="2"/>
                        <line x1="16" y1="2" x2="16" y2="6"/>
                        <line x1="8" y1="2" x2="8" y2="6"/>
                        <line x1="3" y1="10" x2="21" y2="10"/>
                      </svg>
                      <span>{item.date}</span>
                    </div>
                  </td>
                  <td>
                    <span className="timing-pill">{item.time}</span>
                  </td>
                  <td>
                    <span className="venue-tag">{item.room}</span>
                  </td>
                  <td>
                    <span className="seat-badge">{item.seatNumber}</span>
                  </td>
                  <td>
                    <span className={`exam-status-tag ${isEligible ? 'status-confirmed' : 'status-hold'}`}>
                      {isEligible ? (item.status || "Confirmed") : "Withheld"}
                    </span>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Examination Code of Conduct Footer */}
      <div className="exam-rules-strip">
        <div className="rule-item">
          <strong>ID Card Mandatory:</strong> Physical student ID card and printed Hall Ticket required at entrance.
        </div>
        <div className="rule-item">
          <strong>Reporting Time:</strong> Report at least 30 minutes before exam commencement. Electronic gadgets prohibited.
        </div>
      </div>

      {/* Simple Admit Card Modal Preview */}
      {showAdmitCardModal && (
        <div className="modal-backdrop" onClick={() => setShowAdmitCardModal(false)}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()}>
            <div className="modal-header">
              <h3>Official Examination Hall Ticket</h3>
              <button 
                type="button" 
                className="modal-close-btn"
                onClick={() => setShowAdmitCardModal(false)}
              >
                ✕
              </button>
            </div>
            <div className="modal-body admit-card-printable">
              <div className="admit-card-header">
                <h4>Apex Institute of Technology & Sciences</h4>
                <p>Office of the Controller of Examinations</p>
                <div className="admit-stamp">VERIFIED & AUTHORIZED</div>
              </div>
              <div className="admit-student-info">
                <p><strong>Candidate Name:</strong> {studentName}</p>
                <p><strong>Roll / Registration No:</strong> {rollNumber}</p>
                <p><strong>Status:</strong> Eligible (Attendance criterion cleared)</p>
              </div>
              <p className="admit-instructions">
                This digital hall ticket verifies authorization to enter the examination center. Valid photo ID must be presented upon request.
              </p>
            </div>
            <div className="modal-footer">
              <button 
                type="button" 
                className="btn-primary"
                onClick={() => {
                  window.print();
                }}
              >
                Print / Save PDF
              </button>
              <button 
                type="button" 
                className="btn-secondary"
                onClick={() => setShowAdmitCardModal(false)}
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}
