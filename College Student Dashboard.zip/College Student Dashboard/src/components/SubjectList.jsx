import React, { useState } from 'react';

/**
 * SubjectList Component
 * Displays the registered academic subjects using Array.prototype.map().
 * 
 * @param {Object} props
 * @param {Array} props.subjects - Array of subject objects
 */
export default function SubjectList({ subjects = [] }) {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState('All');

  // Filter subjects based on search query and type
  const filteredSubjects = subjects.filter((sub) => {
    const matchesSearch =
      sub.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      sub.code.toLowerCase().includes(searchTerm.toLowerCase()) ||
      sub.faculty.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesType =
      filterType === 'All' ||
      (filterType === 'Lab' && (sub.type.includes('Lab') || sub.type.includes('Practical'))) ||
      (filterType === 'Theory' && sub.type.includes('Theory'));

    return matchesSearch && matchesType;
  });

  const totalCredits = subjects.reduce((sum, item) => sum + (item.credits || 0), 0);

  return (
    <section className="card subject-card" aria-label="Course Subjects">
      <div className="card-header-bar">
        <div>
          <h2 className="card-title">Enrolled Subjects & Curriculum</h2>
          <p className="card-subtitle">
            {subjects.length} Total Registered Courses • <strong>{totalCredits}</strong> Total Academic Credits
          </p>
        </div>

        <div className="subject-filter-controls">
          <input
            type="text"
            className="subject-search-input"
            placeholder="Search code, subject or faculty..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            aria-label="Search subjects"
          />
          <select 
            className="filter-select"
            value={filterType}
            onChange={(e) => setFilterType(e.target.value)}
            aria-label="Filter subjects by category"
          >
            <option value="All">All Types</option>
            <option value="Theory">Theory</option>
            <option value="Lab">Lab / Practical</option>
          </select>
        </div>
      </div>

      {filteredSubjects.length === 0 ? (
        <div className="empty-filter-state">
          <p>No subjects found matching your search.</p>
        </div>
      ) : (
        <div className="subjects-table-container">
          <table className="subjects-table">
            <thead>
              <tr>
                <th>Code</th>
                <th>Course Name</th>
                <th>Credits</th>
                <th>Faculty</th>
                <th>Course Type</th>
                <th>Subject Attendance</th>
                <th>Target Grade</th>
              </tr>
            </thead>
            <tbody>
              {/* Using Array.prototype.map() to dynamically render each subject */}
              {filteredSubjects.map((subject, index) => (
                <tr key={subject.code || index} className="subject-row">
                  <td className="subject-code-cell">
                    <span className="code-badge">{subject.code}</span>
                  </td>
                  <td className="subject-name-cell">
                    <strong>{subject.name}</strong>
                  </td>
                  <td className="subject-credits-cell">
                    <span className="credit-pill">{subject.credits} Credits</span>
                  </td>
                  <td className="subject-faculty-cell">
                    <span className="faculty-name">{subject.faculty}</span>
                  </td>
                  <td>
                    <span className={`type-tag ${subject.type.toLowerCase().includes('lab') || subject.type.toLowerCase().includes('practical') ? 'type-lab' : 'type-theory'}`}>
                      {subject.type}
                    </span>
                  </td>
                  <td>
                    <div className="mini-attendance-gauge">
                      <div className="gauge-track">
                        <div 
                          className={`gauge-fill ${subject.attendance >= 75 ? 'fill-good' : 'fill-warn'}`}
                          style={{ width: `${subject.attendance}%` }}
                        ></div>
                      </div>
                      <span className={`gauge-text ${subject.attendance >= 75 ? 'text-good' : 'text-warn'}`}>
                        {subject.attendance}%
                      </span>
                    </div>
                  </td>
                  <td>
                    <span className="grade-pill">{subject.grade || 'N/A'}</span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </section>
  );
}
