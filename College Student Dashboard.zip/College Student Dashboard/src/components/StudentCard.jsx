import React from 'react';

/**
 * StudentCard Component (Bonus Challenge)
 * Reusable student card with a "View Profile" button to select and view different students.
 *
 * @param {Object} props
 * @param {Object} props.student - Student details
 * @param {boolean} props.isSelected - Whether this card is the currently active student
 * @param {Function} props.onSelect - Callback invoked when "View Profile" is clicked
 */
export default function StudentCard({ student, isSelected, onSelect }) {
  if (!student) return null;

  const { id, name, rollNumber, branch, year, avatar, attendance } = student;
  const isEligible = attendance.percentage >= (attendance.minRequired || 75.0);

  return (
    <div 
      className={`student-card-item ${isSelected ? 'selected' : ''}`}
      onClick={() => onSelect(student.id)}
      role="button"
      tabIndex={0}
      onKeyDown={(e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          onSelect(student.id);
        }
      }}
      aria-label={`Select student profile for ${name}`}
    >
      <div className="card-top-row">
        <div className="card-avatar-box">
          <img src={avatar} alt={name} className="card-avatar-img" />
          {isSelected && <span className="current-active-tag">Active</span>}
        </div>
        <span className={`card-attendance-badge ${isEligible ? 'badge-good' : 'badge-alert'}`}>
          {attendance.percentage}% Attd.
        </span>
      </div>

      <div className="card-info-box">
        <h3 className="card-student-name">{name}</h3>
        <p className="card-roll-number">{rollNumber}</p>
        <p className="card-branch-text" title={branch}>{branch}</p>
        <p className="card-year-text">{year}</p>
      </div>

      <div className="card-action-box">
        <button
          type="button"
          className={`btn-view-profile ${isSelected ? 'btn-view-active' : ''}`}
          onClick={(e) => {
            e.stopPropagation();
            onSelect(student.id);
          }}
          id={`btn-view-profile-${id}`}
        >
          {isSelected ? "Active Profile ✓" : "View Profile →"}
        </button>
      </div>
    </div>
  );
}
