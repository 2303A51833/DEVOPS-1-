import React from 'react';

/**
 * Footer Component
 * Displays institutional copyright, academic accreditation, portal version, and support.
 *
 * @param {Object} props
 * @param {string} props.collegeName - Name of the college
 */
export default function Footer({ collegeName = "Apex Institute of Technology & Sciences" }) {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="dashboard-footer">
      <div className="footer-content-inner">
        <div className="footer-brand">
          <div className="footer-logo">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M22 10v6M2 10l10-5 10 5-10 5z"/>
              <path d="M6 12v5c3 3 9 3 12 0v-5"/>
            </svg>
            <strong>{collegeName}</strong>
          </div>
          <p className="footer-accreditation">
            Approved by AICTE • NAAC Accredited 'A++' Grade • Autonomous Institution
          </p>
        </div>

        <div className="footer-links-group">
          <div className="footer-link-col">
            <span className="footer-header">Academic Office</span>
            <span>Controller of Examinations (CoE)</span>
            <span>Dean of Student Affairs</span>
          </div>
          <div className="footer-link-col">
            <span className="footer-header">Student Support</span>
            <span>Helpline: +91 (0) 800-456-7890</span>
            <span>Email: helpdesk@apex.edu</span>
          </div>
        </div>
      </div>

      <div className="footer-bottom-bar">
        <p className="copyright-text">
          &copy; {currentYear} {collegeName}. All rights reserved. Student Management Dashboard System v2.4
        </p>
        <div className="footer-legal">
          <span>Privacy Policy</span>
          <span>•</span>
          <span>Terms of Academic Portal</span>
          <span>•</span>
          <span>System Status: Operational</span>
        </div>
      </div>
    </footer>
  );
}
