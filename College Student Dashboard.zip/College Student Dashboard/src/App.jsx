import React, { useState } from 'react';
import './dashboard.css';

// Import reusable components
import Header from './components/Header.jsx';
import StudentCard from './components/StudentCard.jsx';
import StudentProfile from './components/StudentProfile.jsx';
import Attendance from './components/Attendance.jsx';
import SubjectList from './components/SubjectList.jsx';
import ExamDetails from './components/ExamDetails.jsx';
import Footer from './components/Footer.jsx';

// Import multi-student data
import { studentsData } from './data/studentsData.js';

/**
 * Main Application Component - Student Management Dashboard
 * Manages active student state, provides multi-student switching,
 * and passes props down to all specialized, reusable components.
 */
export default function App() {
  // State for active student selection (defaults to first student)
  const [selectedStudentId, setSelectedStudentId] = useState(studentsData[0].id);

  // Find active student data
  const currentStudent = 
    studentsData.find((stu) => stu.id === selectedStudentId) || studentsData[0];

  // Determine examination eligibility based on attendance (>= 75% threshold)
  const isEligible = 
    currentStudent.attendance.percentage >= (currentStudent.attendance.minRequired || 75.0);

  return (
    <div className="app-wrapper">
      {/* 1. Header Component */}
      <Header
        collegeName="Apex Institute of Technology & Sciences"
        dashboardTitle="Student Management Dashboard"
        academicYear="Spring Semester 2026"
        activeStudent={currentStudent}
      />

      <main className="dashboard-container">
        {/* Bonus Challenge: Reusable StudentCard components to switch profiles */}
        <section className="student-selector-section" aria-label="Student Selection Directory">
          <div className="section-headline">
            <h2>
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/>
                <circle cx="9" cy="7" r="4"/>
                <path d="M23 21v-2a4 4 0 0 0-3-3.87"/>
                <path d="M16 3.13a4 4 0 0 1 0 7.75"/>
              </svg>
              Student Directory (Bonus Challenge)
            </h2>
            <span className="section-hint">
              Select any student card to view their profile, dynamic attendance & exam eligibility
            </span>
          </div>

          <div className="student-cards-grid">
            {studentsData.map((student) => (
              <StudentCard
                key={student.id}
                student={student}
                isSelected={student.id === currentStudent.id}
                onSelect={(id) => setSelectedStudentId(id)}
              />
            ))}
          </div>
        </section>

        {/* 2. StudentProfile Component (Receives student details via props) */}
        <StudentProfile student={currentStudent} />

        {/* 3. Attendance Component (Dynamic percentage + Conditional "Eligible" / "Not Eligible") */}
        <Attendance attendance={currentStudent.attendance} />

        {/* 4. SubjectList Component (Receives subjects array via props & renders with map) */}
        <SubjectList subjects={currentStudent.subjects} />

        {/* 5. ExamDetails Component (Displays exam schedule, room, seat & admit card) */}
        <ExamDetails
          exams={currentStudent.exams}
          isEligible={isEligible}
          studentName={currentStudent.name}
          rollNumber={currentStudent.rollNumber}
        />
      </main>

      {/* 6. Footer Component (Displays college copyright and accreditation) */}
      <Footer collegeName="Apex Institute of Technology & Sciences" />
    </div>
  );
}
